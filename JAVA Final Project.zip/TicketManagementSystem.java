import userGUI.LogInFrame;

public class TicketManagementSystem
{
	public static void main(String [] args)
	{
		LogInFrame login=new LogInFrame();
	}
}