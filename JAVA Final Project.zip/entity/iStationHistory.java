package entity;

public interface iStationHistory
{
	public  StationHistory [] getAllStationHistory();
	
}