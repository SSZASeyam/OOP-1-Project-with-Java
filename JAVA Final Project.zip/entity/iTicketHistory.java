package entity;

public interface iTicketHistory
{
	public  TicketHistory [] getAllTicketHistory();
	
}