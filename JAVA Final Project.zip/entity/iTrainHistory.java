package entity;

public interface iTrainHistory
{
	public  TrainHistory [] getAllTrainHistory();
	
}