package entity;

public interface iTrainCoachHistory
{
	public  TrainCoachHistory [] getAllTrainCoachHistory();
	
}